package com.kakao.han3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import android.os.Debug;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;


public class Menu1 extends AppCompatActivity {
    public boolean s3, s4, s5,OnOff;
    static final int REQUEST_ENABLE_BT = 10; // 블루투스 활성화 상태
    BluetoothAdapter bluetoothAdapter; // 블루투스 어댑터
    Set<BluetoothDevice> devices; // 블루투스 디바이스 데이터 셋
    BluetoothDevice bluetoothDevice; // 블루투스 디바이스
    BluetoothSocket bluetoothSocket = null;
    int pariedDeviceCount;
    TextView PitchtextView;
    TextView Bluetoothname;
    Button BluetoothBt;
    View Bluetoothset;
    View speedset;
    View volset;
    Switch asd;
    SeekBar seekBar;
    public static Context context_main; // context 변수 선언(메뉴 변수 사용 위함)
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        asd = findViewById(R.id.switch2);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        Bluetoothname = findViewById(R.id.textView5);
        speedset = findViewById(R.id.SpeedConstraintLayout);
        volset = findViewById(R.id.volConstraintLayout2);
        Bluetoothset = findViewById(R.id.Bluetooth_constraintLayout);
        PitchtextView = findViewById(R.id.textView10);
        seekBar = findViewById(R.id.seekBar);
        context_main = this;

        spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.test, android.R.layout.simple_spinner_dropdown_item);
        // android.R.layout.simple_spinner_dropdown_item은 기본으로 제공해주는 형식입니다.
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter); //어댑터에 연결해줍니다.
        BluetoothBt = findViewById(R.id.button2);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            } //이 오버라이드 메소드에서 position은 몇번째 값이 클릭됬는지 알 수 있습니다.
            //getItemAtPosition(position)를 통해서 해당 값을 받아올수있습니다.

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
       seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                PitchtextView.setText(String.format("     볼륨: %d", seekBar.getProgress()));
            }
        });

        if (bluetoothAdapter.isEnabled()) {  //블루투스가 켜져있다면 "연결", 꺼져있다면 "실행" 으로 버튼 텍스트 변경
            BluetoothBt.setText("블루투스 연결");
        } else {
            BluetoothBt.setText("블루투스 실행");
        }
        Switch switch3 = (Switch) findViewById(R.id.switch3);
        switch3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    s3 = true;
                }else{
                    s3=false;
                }
            }
        });
        Switch switch4 = (Switch) findViewById(R.id.switch4);
        switch4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    s4 = true;
                }else{
                    s4=false;
                }
            }
        });
        Switch switch5 = (Switch) findViewById(R.id.switch5);
        switch5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    s5 = true;
                }else{
                    s5=false;
                }
            }
        });
        Switch onoff = (Switch) findViewById(R.id.switch2);
        onoff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    OnOff = true;
                }else{
                    OnOff=false;
                }
            }
        });

    }


    public void bluetooth_setings(View view) {
        /*Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        startActivity(intent);*/
        if (bluetoothAdapter == null) { // 디바이스가 블루투스를 지원하지 않을 때
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("블루투스 실행 실패").setMessage("디바이스가 블루투스를 지원하지 않습니다");
            builder.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {

                }
            });
            AlertDialog alertDialog = builder.create();

            alertDialog.show();

        } else { // 디바이스가 블루투스를 지원 할 때

            if (bluetoothAdapter.isEnabled()) { // 블루투스가 활성화 상태 (기기에 블루투스가 켜져있음)
                selectBluetoothDevice(); // 블루투스 디바이스 선택 함수 호출

            } else { // 블루투스가 비 활성화 상태 (기기에 블루투스가 꺼져있음)

                // 블루투스를 활성화 하기 위한 다이얼로그 출력

                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(intent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {

            case REQUEST_ENABLE_BT:

                if (requestCode == RESULT_OK) { // '사용'을 눌렀을 때
                    selectBluetoothDevice(); // 블루투스 디바이스 선택 함수 호출
                    BluetoothBt.setText("블루투스 연결");
                } else { // '취소'를 눌렀을 때


                }
                break;
        }
    }

    public void selectBluetoothDevice() {

        devices = bluetoothAdapter.getBondedDevices();

        pariedDeviceCount = devices.size();

        if (pariedDeviceCount == 0) {
            // 페어링 되어있는 장치가 없는경우
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("페어링 되어있는 장치가 없습니다");
            builder.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        } else {
            // 페어링 되어있는 장치가 있는 경우
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("페어링 되어있는 블루투스 디바이스 목록");

            List<String> list = new ArrayList<>();

            // 모든 디바이스의 이름을 리스트에 추가

            for (BluetoothDevice bluetoothDevice : devices) {
                list.add(bluetoothDevice.getName());
            }
            list.add("취소");

            // List를 CharSequence 배열로 변경
            final CharSequence[] charSequences = list.toArray(new CharSequence[list.size()]);

            list.toArray(new CharSequence[list.size()]);

            // 해당 아이템을 눌렀을 때 호출 되는 이벤트 리스너
            builder.setItems(charSequences, new DialogInterface.OnClickListener() {

                @Override

                public void onClick(DialogInterface dialog, int which) {

                    // 해당 디바이스와 연결하는 함수 호출
                    connectDevice(charSequences[which].toString());
                    // Bluetoothname.setText(charSequences[which].toString());
                }

            });

            // 뒤로가기 버튼 누를 때 창이 안닫히도록 설정
            builder.setCancelable(false);

            // 다이얼로그 생성

            AlertDialog alertDialog = builder.create();

            alertDialog.show();
        }
    }

    public void connectDevice(String deviceName) {
        for (BluetoothDevice tempDevice : devices) {
            if (deviceName.equals(tempDevice.getName())) {
                bluetoothDevice = tempDevice;
                Bluetoothname.setText(deviceName);
                break;
            }
        }
        // UUID 생성

        UUID uuid = java.util.UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

        // Rfcomm 채널을 통해 블루투스 디바이스와 통신하는 소켓 생성

        try {
            bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(uuid);
            bluetoothSocket.connect();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    int i;

    public void speedsetClick(View view) {

        if (i == 1) {
            speedset.setVisibility(View.GONE);
            i = 0;
        } else {
            speedset.setVisibility(View.VISIBLE);
            i = 1;
        }
    }

    int i1;

    public void VolsetClick(View view) {

        if (i1 == 1) {
            volset.setVisibility(View.GONE);
            i1 = 0;
        } else {
            volset.setVisibility(View.VISIBLE);
            i1 = 1;
        }
    }

    int i2;

    public void Bluetooth_Click(View view) {

        if (i2 == 1) {
            Bluetoothset.setVisibility(View.GONE);
            i2 = 0;
        } else {
            Bluetoothset.setVisibility(View.VISIBLE);
            i2 = 1;
        }
    }
}