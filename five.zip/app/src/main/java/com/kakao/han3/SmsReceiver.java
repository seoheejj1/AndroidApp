package com.kakao.han3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsMessage;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SmsReceiver extends BroadcastReceiver {
    private static SimpleDateFormat format = new SimpleDateFormat("yyyy년MM월dd일 hh:mm");
    public String sandSMS = "sms";
    public SmsReceiver() {

    }

    @Override
    public void onReceive(Context context, Intent intent) {
        sandSMS = "sms";
        // SMS_RECEIVED에 대한 액션일때 실행
        if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {
            System.out.println(sandSMS+"");
            // Bundle을 이용해서 메세지 내용을 가져옴
            Bundle bundle = intent.getExtras();
            SmsMessage[] messages = parseSmsMessage(bundle);

            // 메세지가 있을 경우 내용을 로그로 출력해 봄
            if (messages.length > 0) {
                // 문자메세지에서 송신자와 관련된 내용을 뽑아낸다.
                String sender = messages[0].getOriginatingAddress();
                Date receivedDate = new Date(messages[0].getTimestampMillis());
//                String name = GetName(context, sender);
                // 문자메세지 내용 추출
                String contents = messages[0].getMessageBody().toString();

                Log.d("SmsReceiver", "Sender :" + sender);
                Log.d("SmsReceiver", "contents :" + contents);
                Log.d("SmsReceiver", "receivedDte :" + receivedDate);
                sandSMS = sender + contents + receivedDate.toString();
                // On/Off 기능
                if (((Menu1)Menu1.context_main).OnOff) {
                    sendToActivity(context, sender, contents, receivedDate);// 메세지 전달
                }
            }
        }
    }

    // 액티비티로 메세지의 내용을 전달해줌 (정보)
    private void sendToActivity(Context context, String sender, String contents, Date receivedDate) {
        Intent intent = new Intent(context, MainActivity.class);

        // Flag 설정
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        if(((Menu1)Menu1.context_main).s3 == true){
            intent.putExtra("sender", " "+sender);
            System.out.println("s3 켜짐");
        }else {
            intent.putExtra("sender", "");
        }
        if(((Menu1)Menu1.context_main).s4 == true){
            intent.putExtra("contents", " "+contents);
            System.out.println("s4 켜짐");
        }else {
            intent.putExtra("contents", "");
        }
        if(((Menu1)Menu1.context_main).s5 == true) {
            intent.putExtra("receivedDate", " "+format.format(receivedDate));
            System.out.println("s5 켜짐");
        }else {
            intent.putExtra("receivedDate", "");
        }
        // 정보를 Extra에 넣어줌

        context.startActivity(intent);
    }

    private String GetName(Context context, String str) {
        String name = "str";

        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(str));
        String[] projection = new String[] {ContactsContract.PhoneLookup.DISPLAY_NAME};

        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                name = cursor.getString(0);
            }
            cursor.close();
        }
        return name;
    }
    // 액티비티로 메세지의 내용을 전달해줌 (송신자와 관련된 내용, 문자메세지 내용, 수신 날짜/시간 데이터)
  /* private void sendToActivity2(Context context, String sender, String contents, Date receivedDate) {
        Intent intent = new Intent(context, MainActivity.class);

        // Flag 설정
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        if(((Menu1)Menu1.context_main).s3 == true){
            intent.putExtra("sender", sender);
        }
        if(((Menu1)Menu1.context_main).s4 == true){
            intent.putExtra("contents", contents);
        }
        if(((Menu1)Menu1.context_main).s5 == true) {
            intent.putExtra("receivedDate", format.format(receivedDate));
        }
        context.startActivity(intent);
    }*/

    private SmsMessage[] parseSmsMessage(Bundle bundle) {
        Object[] objs = (Object[]) bundle.get("pdus");
        SmsMessage[] messages = new SmsMessage[objs.length];

        for (int i = 0; i < objs.length; i++) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                String format = bundle.getString("format");
                messages[i] = SmsMessage.createFromPdu((byte[]) objs[i], format);
            } else {
                messages[i] = SmsMessage.createFromPdu((byte[]) objs[i]);
            }
        }

        return messages;
    }
}
