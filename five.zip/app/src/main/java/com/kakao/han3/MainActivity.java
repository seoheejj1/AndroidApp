package com.kakao.han3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.time.temporal.ValueRange;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener, ImageButton.OnClickListener {
    Bundle vol = new Bundle();
    ImageButton imagebutton;
    private SmsReceiver smsReceiver;
    private int isTTSReady = TextToSpeech.STOPPED;
    private TextView editText;
    //TTS
    private TextToSpeech tts;
    private EditText edtSpeech;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        System.out.println(test.aaa);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        imagebutton = (ImageButton) findViewById(R.id.menuicon);
        imagebutton.setOnClickListener(this);

        // SMS Receiver 생성
        smsReceiver = new SmsReceiver();
        // TextToSpeech 생성
        tts = new TextToSpeech(this, this);
        // 텍스트뷰 생성
        editText = (TextView) findViewById(R.id.SMSText);

        // (1) 리시버에 의해 해당 액티비티가 새롭게 실행된 경우
        Intent passedIntent = getIntent();
        processIntent(passedIntent);

        // 퍼미션 (권한 확인하기)
        int permission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS);
        if (permission == PackageManager.PERMISSION_GRANTED) {
            // 권한이 설정 되어 있으면
            Toast.makeText(this, "SMS 수신 권한 주어져 있음.", Toast.LENGTH_LONG).show();
        } else {
            // 권한이 설정 되어 있지 않으면 권한 설정창 띄워주기
            Toast.makeText(this, "SMS 수신 권한 없음.", Toast.LENGTH_LONG).show();
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS)) {
                Toast.makeText(this, "SMS 권한 설명 필요함.", Toast.LENGTH_LONG).show();
            } else {
                // 시스템이 대화상자를 띄워서 사용자에게 권한요청을 한다.
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, 1);
                // 위 코드의 결과가 Toast메시지로써 보여질 수 있도록 콜백함수를 사용한다(onRequestPermissionsResult() override)
            }
        }
    }

    private void Speech() {
        String text = edtSpeech.getText().toString();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);

        } else
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }


    // override method 통해서 직접 오버라이딩 해준다.
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                        Toast.makeText(this, "SMS 수신권한을 사용자가 승인함", Toast.LENGTH_LONG).show();
                    else if (grantResults[0] == PackageManager.PERMISSION_DENIED)
                        Toast.makeText(this, "SMS 수신권한을 사용자가 거부함", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(this, "SMS 수신권한을 부여받지 못함", Toast.LENGTH_LONG).show();
                }
        }
    }

    // 처음 실행시 새로 생성
    private void processIntent(Intent intent) {
        if (intent != null) {

            // 인텐트에서 전달된 데이터를 추출하여, 활용한다.(여기서는 edittext를 통하여 내용을 화면에 뿌려주었다.)
            editText.setText("   "+intent.getStringExtra("sender") + intent.getStringExtra("contents")+ intent.getStringExtra("receivedDate"));
            TextToSpeech("   "+intent.getStringExtra("sender") + intent.getStringExtra("contents")+ intent.getStringExtra("receivedDate"));
        }
    }

    // (2) 이미 실행된 상태였는데 리시버에 의해 다시 켜진 경우
    // (이러한 경우 onCreate()를 거치지 않기 때문에 이렇게 오버라이드 해주어야 모든 경우에 SMS문자가 처리된다!
    @Override
    protected void onNewIntent(Intent intent) {
        processIntent(intent);
        super.onNewIntent(intent);
    }


    public void onInit(int status) {
        // 작업 성공시
        if (status == TextToSpeech.SUCCESS) {
            // 언어 설정
            int language = tts.setLanguage((Locale.KOREAN));
            // 만약 데이터가 없거나 지원하지 않는 경우
            if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                editText.setText("지원하지 않는 언어입니다.");
            } else {
                isTTSReady = status;
            }
        } else {
            editText.setText("TTS 작업이 실패하였습니다.");
        }
    }

    // 문자 읽어주기
    public void TextToSpeech(String str) {

        if (isTTSReady == TextToSpeech.SUCCESS) {
            int var = ((Menu1)Menu1.context_main).seekBar.getProgress();//메뉴 seek bar 값 가져오기
                vol.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, var*0.01f);
            //Log.d("Debug", String.valueOf(var2*0.01));
            // 음향
            tts.setPitch((float) 1.0);
            // 재생 속도
            tts.setSpeechRate((float) 1.0);
            // 재생
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // 안드로이드 버전이 롤리팝 이상이면
                int result = tts.speak(str, TextToSpeech.QUEUE_FLUSH, vol, TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID);
                if (result >= 0)
                    Log.d("SMSToSpeech", "=====> TextToSpeech LOLLIPOP speak SUCCESS <=====" + str);
                else
                    Log.d("SMSToSpeech", "=====> TextToSpeech LOLLIPOP speak ERROR <=====" + str);
            } else {
                HashMap<String, String> map = new HashMap<String, String>();
                map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "UniqueID");
                tts.speak(str, TextToSpeech.QUEUE_FLUSH, map);
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.menuicon:

                Intent intent = new Intent(MainActivity.this, Menu1.class);
                startActivity(intent);
                break;

        }

    }

}